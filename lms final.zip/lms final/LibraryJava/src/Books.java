
import java.io.Serializable;
import java.util.Date;

public class Books implements Serializable {
	 int Id;
     int memberId;
     String date;
      String convertedDate;
     Bookdetail book = new Bookdetail();
     public Books() {
 		Id = 0;
 		memberId = 0;
 		date = null;
 		convertedDate = null;
 		book = null;
 	}


	public Books(int Id,int memberId,String date,String  convertedDate,Bookdetail book) {
		
		this.Id = Id;
		this.memberId = memberId;
		this.date = date;
		this.convertedDate = convertedDate;
		this.book = book;
	}
 	
	

	@Override
	public String toString() {
		
return "\n Id_Of_Book : " + Id +"\nmemberId: "+ memberId + "\n date and time :" + date + "\n Return-Date" + convertedDate + book;
	}
    
 
}
