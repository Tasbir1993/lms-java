
public class Showbook {
	int BookCode[];
	 String BookName[];
		    String bookCategory[];
		    String bookAuther[];
		    // 9914313202
		    	void show(Showbook b) {
		    		System.out.println("Book Code\tBook Name\t\tbookCategory\t\tbookAuther");
		    		
		    		for(int i = 0;i<b.getBookCode().length;i++) {
		    			System.out.println(b.BookCode[i]+"\t\t"+b.BookName[i]+"\t\t"+b.bookCategory[i]+"\t\t\t"+b.bookAuther[i]);
			    		}
		    		 	}
		    
		    	void showComputer(Showbook b) {

		    		int k=0;
		    		for(int i= 0;i<b.bookCategory.length;i++) {
		    			
		    			
		    			if(b.bookCategory[i]=="computer") {
		    				k++;
		    			}
		    				
		    		}
		    		System.out.println("Computer Books  : "+k);
		    	
		    	
		    		
		    	}
		    	
		    	public int[] getBookCode() {
				return BookCode;
			}
			public void setBookCode(int[] bookCode) {
				BookCode = bookCode;
			}
			public String[] getBookName() {
				return BookName;
			}
			public void setBookName(String[] bookName) {
				BookName = bookName;
			}
			public String[] getBookCategory() {
				return bookCategory;
			}
			public void setBookCategory(String[] bookCategory) {
				this.bookCategory = bookCategory;
			}
			public String[] getBookAuther() {
				return bookAuther;
			}
			public void setBookAuther(String[] bookAuther) {
				this.bookAuther = bookAuther;
			}
			
		


}
