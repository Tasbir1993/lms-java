import java.util.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

class Main {
	
	static String fileName = null;
	static Library lib = new Library();
	
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	String date = (df.format(dateobj));
	
	
	
	
	
	private Boolean running = true;
	Scanner in = new Scanner(System.in);
	 void report() throws Exception {
		
		 int BookCode[]= {1,2,3,4};
			String BookName[]= {"computer","Advance Science","GK"," Basicpunjabi"};
			 String bookCategory[]= {"computer","Science","Cultureer","punjabi"};
			 String bookAuther[]= {"marcos bittencourt","raspal singh","raspal singh","marcos bittencourt"};
			
		

			Showbook bk = new Showbook();
				bk.setBookCode(BookCode);
				bk.setBookName(BookName);
				bk.setBookCategory(bookCategory);
				bk.setBookAuther(bookAuther);
				
			
			
			while(running) {
			
		 System.out.println ("press 1 to see how many books are in Library//REPORT ONE \n ");
		 System.out.println ("press 2 to see the number of computer books in library//REPORT TWO \n ");

		System.out.println ("enter 3 for loading a library\n ");
		System.out.println ("enter 4 for save and quit\n");
		System.out.println ("enter 5 for list and books in library\n");
		System.out.println ("enter 6 for issue books from lobrary\n");
		
		int ans = in.nextInt();
		switch(ans) {
		case 1:
			bk.show(bk);
		break;
		case 2:
			bk.showComputer(bk);	
		break;
		case 3:
			// System.out.println("enter file name to loard");
			   loadScript();
		break;
		case 4:
			saveandquit();
			break;
		case 5:
			System.out.println(lib.toString());
		     break;
		case 6:
			addBook();
			break;
			
			
		}
	  }
			System.exit(0);
	}

	private void loadScript() throws Exception  {
		// TODO Auto-generated method stub
		FileInputStream fis = null;
		ObjectInputStream in = null;
		
		File file = new File("tasbir.txt");
		//if(file.exists())
		{
		try {
			fis = new FileInputStream(file);
			in = new ObjectInputStream(fis);
			lib = (Library) in.readObject();
			fis.close();
			in.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("\n the file does not exist.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}//else {
		//	System.out.println("\n the file does not exist.");
		//}
		
	}

	private void saveandquit() throws IOException {
		// TODO Auto-generated method stub
		 File f2 = new File("tasbir.txt");
		  f2.createNewFile();
		
		running = false;
		FileOutputStream fos = null;
		ObjectOutputStream out = null;
		try {
			
			//fos = new FileOutputStream(f2);
			fos = new FileOutputStream(f2);
			out = new ObjectOutputStream(fos);
			out.writeObject(lib);
			out.flush();
			fos.close();
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void addBook() {
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yy" );   
		Calendar cal = Calendar.getInstance();    
		    
		cal.add( Calendar.DATE, 7 );    
		String convertedDate=dateFormat.format(cal.getTime());    
		//System.out.println("Date increase by one.."+convertedDate);
		
		//Calendar cal = Calendar.getInstance();
		//cal.add(Calendar.DATE, 7);
		//System.out.println("Date = "+ cal.getTime());
		//Date c = (cal.getTime());
		
		// TODO Auto-generated method stub
		
	//  ArrayList<Bookdetail> book = new ArrayList<Bookdetail>();
		Bookdetail bo = new Bookdetail("computer","marcos bittencourt");
		Bookdetail bo1 = new Bookdetail("science","raspal singh");
        Bookdetail bo3 = new Bookdetail("GK","raspal singh");
        Bookdetail bo4 = new Bookdetail("basic Punjabi","marcos bittencourt");
		Bookdetail o = new Bookdetail();
		
		int Id;
	int memberId;
	     System.out.println("\n Enter the Id of book: ");
	     Id = in.nextInt();
	    if(Id == 1) {
	    	o = bo;
	    }else if(Id == 2){
	    	o = bo1;
	    }else if (Id == 3) {
	    	o = bo3;
	    }else if (Id == 4) {
	    	o = bo4;
	    }else {
	    	System.out.println("enter correct Id please.");
	    }
	     System.out.println("\n Enter the member Id please.: ");
        memberId = in.nextInt();
	     
	     Books b = new Books(Id ,memberId ,(df.format(dateobj)) , convertedDate, o);
		 lib.addBooks(b);
	}

	public static void main(String arf[]) throws Exception {
		Main ob = new Main();
		ob.report();
	}
}
