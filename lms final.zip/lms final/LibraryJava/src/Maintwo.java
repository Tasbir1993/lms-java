import java.util.Calendar;

public class Maintwo {

	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DATE, 7);
				System.out.println("Date = "+ cal.getTime());

	}

}
