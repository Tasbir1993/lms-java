import java.io.Serializable;



public class Bookdetail implements Serializable {
		
		 String BookName;
	    
	     String bookAuther;
	     
	     public Bookdetail() {
	    	 BookName = "NA ";
	    
	    	 bookAuther = "NA ";
	    	 
	     } 
			 
	     public Bookdetail(String b,String Ba) {
	    	 BookName = b;
	    	
	    	 bookAuther = Ba;
	    	 
	     }
			  
		

		public String toString() {
			return "\nbookname : " + BookName + " \nAuther: " + bookAuther ;
		}
			    	
			    
				/* public String getBookName() {
					return BookName;
				}
				public void setBookName(String bookName) {
					BookName = bookName;
				}
				public String getBookCategory() {
					return bookCategory;
				}
				public void setBookCategory(String bookCategory) {
					this.bookCategory = bookCategory;
				}
				public String getBookAuther() {
					return bookAuther;
				}
				public void setBookAuther(String bookAuther) {
					this.bookAuther = bookAuther;
				}
			*/
			
	

	
}
